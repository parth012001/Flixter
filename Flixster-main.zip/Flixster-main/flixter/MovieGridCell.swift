//
//  MovieGridCell.swift
//  flixter
//
//  Created by Subohi Agarwal on 10/31/20.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
